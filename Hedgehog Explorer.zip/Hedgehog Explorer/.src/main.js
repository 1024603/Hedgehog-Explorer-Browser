const { app, BrowserWindow, ipcMain, Menu, session, shell, dialog } = require('electron');
const path = require('path');

let adBlockEnabled = true;

function createWindow(isIncognito = false) {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    title: isIncognito ? "Hedgehog Explorer (Incognito)" : "Hedgehog Explorer",
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      webviewTag: true
    }
  });

  win.loadFile(path.join(__dirname, 'index.html'));

  win.webContents.on('did-finish-load', () => {
    if (isIncognito) win.webContents.send('set-incognito');
  });

  // Automatically deny ALL permission requests with no dialog
  win.webContents.session.setPermissionRequestHandler((webContents, permission, callback) => {
    callback(false);
  });

  // Safe Download Warning
  win.webContents.session.on('will-download', (event, item) => {
    const choice = dialog.showMessageBoxSync(win, {
      type: 'warning',
      buttons: ['Download', 'Cancel'],
      title: 'Download Warning',
      message: `Are you sure you want to download: ${item.getFilename()}?`
    });
    if (choice === 1) event.preventDefault();
  });
}

// Function to spawn the dedicated Chrome-style History Manager window
function openHistoryWindow() {
  const historyWin = new BrowserWindow({
    width: 800,
    height: 600,
    title: "History",
    resizable: true,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  historyWin.loadFile(path.join(__dirname, 'history.html'));
}

// IPC Communications Link between UI and System Main Process
ipcMain.on('open-incognito-window', () => createWindow(true));
ipcMain.on('toggle-adblock', (event, enabled) => { adBlockEnabled = enabled; });
ipcMain.on('open-history-page', () => openHistoryWindow());

// Native System Application Menu Layout
function generateMenu() {
  const template = [
    {
      label: 'Hedgehog Explorer',
      submenu: [
        {
          label: 'About Hedgehog Explorer',
          click: () => {
            const aboutWin = new BrowserWindow({
              width: 320,
              height: 240,
              title: "About",
              minimal: true,
              resizable: false,
              webPreferences: { nodeIntegration: true, contextIsolation: false }
            });
            
            // Inline HTML structure for the custom About panel with your custom version links
            const aboutHtml = `
              <!DOCTYPE html>
              <html>
              <body style="background:#202124; color:white; font-family:-apple-system, sans-serif; text-align:center; padding:20px; margin:0;">
                <h2 style="margin-bottom:4px; color:#8ab4f8;">Hedgehog Explorer</h2>
                <div style="font-size:13px; color:#9aa0a6; margin-bottom:16px;">Version: 1.3.7</div>
                <div style="font-size:14px; margin-bottom:20px;">Developer ID: 1024603</div>
                <p style="font-size:12px; line-height:1.6; color:#bdc1c6;">
                  Designed with <a href="#" id="electron-link" style="color:#8ab4f8; text-decoration:none;">Electron</a> 
                  and <a href="#" id="node-link" style="color:#8ab4f8; text-decoration:none;">node.js</a>.
                </p>
                <script>
                  const { shell } = require('electron');
                  document.getElementById('electron-link').onclick = (e) => { e.preventDefault(); shell.openExternal('https://www.electronjs.org/'); };
                  document.getElementById('node-link').onclick = (e) => { e.preventDefault(); shell.openExternal('https://nodejs.org/en'); };
                </script>
              </body>
              </html>
            `;
            aboutWin.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(aboutHtml)}`);
          }
        },
        { type: 'separator' },
        { role: 'quit' }
      ]
    },
    {
      label: 'File',
      submenu: [
        { label: 'New Window', accelerator: 'CmdOrCtrl+N', click: () => createWindow(false) },
        { label: 'New Incognito Window', accelerator: 'CmdOrCtrl+Shift+N', click: () => createWindow(true) }
      ]
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' }, { role: 'redo' }, { type: 'separator' },
        { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }
      ]
    },
    {
      label: 'View',
      submenu: [{ role: 'reload' }, { role: 'toggleDevTools' }]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

app.whenReady().then(() => {
  createWindow();
  generateMenu();
});